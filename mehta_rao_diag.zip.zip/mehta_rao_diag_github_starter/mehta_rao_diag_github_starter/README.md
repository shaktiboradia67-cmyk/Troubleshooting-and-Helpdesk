# Mehta & Rao Associates — System Diagnostic Project

**Organization:** Mehta & Rao Associates  
**Location:** Ahmedabad, Gujarat, India  
**Platform:** Windows laptop  
**Purpose:** Collect a read-only baseline of system, storage, battery, and recent event information.

## Important

This is a starter package. It does **not** contain your laptop's real diagnostic results yet. Run the included PowerShell script on the Windows laptop to create them. Review and redact the resulting reports before uploading them to GitHub.

## 1. Run the collection script

1. Extract this ZIP.
2. Open the extracted folder.
3. Right-click `collect_diagnostics.ps1` and choose **Run with PowerShell**.
4. If Windows blocks the script, open PowerShell in this folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\collect_diagnostics.ps1
```

5. The script creates `mehta_rao_diag` beside itself and saves the reports there.
6. If `powercfg` fails due to permissions, reopen PowerShell as Administrator and run the script again.

The script uses information-gathering commands only. It does not repair, format, clean, or modify disks.

## 2. Capture Reliability Monitor

1. Press `Win + R`.
2. Type `perfmon /rel` and press Enter.
3. Wait for Reliability Monitor to load.
4. Take a screenshot with `Win + Shift + S`.
5. Save it inside `mehta_rao_diag` as `reliability_monitor.png`.

## 3. Review and redact

Before sharing, open the generated text reports and replace your actual:
- Computer name with `XXXX`
- Username with `XXXX`
- Hardware serial numbers with `XXXX`

Also review for private information such as email addresses, network names, IP addresses, installed applications, or organization details. Do not upload anything you do not want public.

## 4. Check the diagnostic index

The script creates `diagnostic_index.txt` using lines found in your actual reports. It marks CPU, RAM, storage, display, and events as `CHECK` pending human review. Do not change a status to `OK` unless the actual evidence supports it.

The required PSU note is included exactly as requested:
`PSU voltage: LAB ONLY - multimeter, not tested at home`

## 5. Expected output

```text
mehta_rao_diag/
├── baseline_systeminfo.txt
├── baseline_dxdiag.txt
├── baseline_msinfo.txt
├── storage_health.txt
├── battery_report.html
├── recent_errors.txt
├── reliability_monitor.png   # add manually
└── diagnostic_index.txt
```

## 6. Create the submission ZIP

After reviewing/redacting the reports and adding the screenshot, right-click the `mehta_rao_diag` folder and choose **Compress to ZIP file** (Windows 11) or **Send to → Compressed (zipped) folder** (Windows 10).

Name it `mehta_rao_diag.zip`.

Only upload the ZIP after verifying that it contains the real reports and the screenshot.
