﻿# Mehta & Rao Associates - read-only Windows diagnostic collection
# Creates .\mehta_rao_diag and collects local diagnostic reports.
# No repair, format, clean, or disk-modification commands are used.

$ErrorActionPreference = "Continue"
$OutputDir = Join-Path $PSScriptRoot "mehta_rao_diag"
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

function Write-Section {
    param([string]$Path, [string]$Title, [string]$Body)
    Add-Content -LiteralPath $Path -Value "`r`n===== $Title =====`r`n$Body`r`n"
}

# 1. System information
$sysPath = Join-Path $OutputDir "baseline_systeminfo.txt"
"Command: systeminfo`r`nCollected: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')`r`n" |
    Set-Content -LiteralPath $sysPath
systeminfo 2>&1 | Out-String | Add-Content -LiteralPath $sysPath

# 2. DirectX diagnostic report
$dxPath = Join-Path $OutputDir "baseline_dxdiag.txt"
try {
    $p = Start-Process -FilePath "dxdiag.exe" -ArgumentList @("/t", "`"$dxPath`"") -PassThru -Wait -ErrorAction Stop
    if (-not (Test-Path -LiteralPath $dxPath)) {
        "dxdiag did not create the expected report. Exit code: $($p.ExitCode)" |
            Set-Content -LiteralPath $dxPath
    }
} catch {
    "Unable to run dxdiag: $($_.Exception.Message)" | Set-Content -LiteralPath $dxPath
}

# 3. System Information report
$msPath = Join-Path $OutputDir "baseline_msinfo.txt"
try {
    Start-Process -FilePath "msinfo32.exe" -ArgumentList @("/report", "`"$msPath`"") -Wait -ErrorAction Stop
    if (-not (Test-Path -LiteralPath $msPath)) {
        "msinfo32 did not create the expected report." | Set-Content -LiteralPath $msPath
    }
} catch {
    "Unable to run msinfo32: $($_.Exception.Message)" | Set-Content -LiteralPath $msPath
}

# 4. Storage health (read-only query)
$storagePath = Join-Path $OutputDir "storage_health.txt"
"Command: Get-PhysicalDisk | Format-List FriendlyName,MediaType,HealthStatus,OperationalStatus`r`n" |
    Set-Content -LiteralPath $storagePath
try {
    Get-PhysicalDisk |
        Format-List FriendlyName,MediaType,HealthStatus,OperationalStatus |
        Out-String | Add-Content -LiteralPath $storagePath
} catch {
    "Storage query error: $($_.Exception.Message)" | Add-Content -LiteralPath $storagePath
}

# 5. Laptop battery report
$batteryPath = Join-Path $OutputDir "battery_report.html"
try {
    & powercfg /batteryreport /output "$batteryPath" 2>&1 |
        Out-String | Add-Content -LiteralPath (Join-Path $OutputDir "battery_report_command.txt")
    if (-not (Test-Path -LiteralPath $batteryPath)) {
        "Battery report was not generated. See battery_report_command.txt. If required, rerun PowerShell as Administrator." |
            Set-Content -LiteralPath (Join-Path $OutputDir "battery_report_note.txt")
    }
} catch {
    "Battery report error: $($_.Exception.Message)" |
        Set-Content -LiteralPath (Join-Path $OutputDir "battery_report_note.txt")
}

# 6. Last seven days of Critical and Error System events
$eventsPath = Join-Path $OutputDir "recent_errors.txt"
$eventCommand = "Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2;StartTime=(Get-Date).AddDays(-7)} -MaxEvents 20"
"Command:`r`n$eventCommand`r`n" | Set-Content -LiteralPath $eventsPath
try {
    $events = Get-WinEvent -FilterHashtable @{
        LogName = 'System'
        Level = 1,2
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 20 -ErrorAction Stop
    if ($events) {
        $events | Format-List TimeCreated,Id,LevelDisplayName,ProviderName,Message |
            Out-String -Width 240 | Add-Content -LiteralPath $eventsPath
    } else {
        "No matching Critical or Error events were returned." | Add-Content -LiteralPath $eventsPath
    }
} catch {
    # Preserve the no-matching-events message (or other query error) as evidence.
    "PowerShell message: $($_.Exception.Message)" | Add-Content -LiteralPath $eventsPath
}

# 7. Index: inventory + actual evidence snippets where available.
$indexPath = Join-Path $OutputDir "diagnostic_index.txt"
@"
MEHTA & RAO ASSOCIATES
SYSTEM DIAGNOSTIC INDEX
Location: Ahmedabad, Gujarat, India
Platform: Windows laptop

FILE INVENTORY
"@ | Set-Content -LiteralPath $indexPath

$inventory = @(
    @("baseline_systeminfo.txt", "systeminfo"),
    @("baseline_dxdiag.txt", "dxdiag /t"),
    @("baseline_msinfo.txt", "msinfo32 /report"),
    @("storage_health.txt", "Get-PhysicalDisk | Format-List FriendlyName,MediaType,HealthStatus,OperationalStatus"),
    @("battery_report.html", "powercfg /batteryreport"),
    @("recent_errors.txt", "Get-WinEvent -FilterHashtable"),
    @("reliability_monitor.png", "Screenshot saved manually from perfmon /rel"),
    @("diagnostic_index.txt", "This script")
)
foreach ($item in $inventory) {
    Add-Content -LiteralPath $indexPath -Value ("- {0} | Tool: {1}" -f $item[0], $item[1])
}

function Add-EvidenceLine {
    param([string]$Label, [string]$Status, [string]$FileName, [string]$Pattern)
    $path = Join-Path $OutputDir $FileName
    $matchText = "No matching evidence line found in $FileName"
    if (Test-Path -LiteralPath $path) {
        $match = Select-String -LiteralPath $path -Pattern $Pattern -CaseSensitive:$false |
            Select-Object -First 1
        if ($match) {
            $matchText = $match.Line.Trim()
        }
    }
    Add-Content -LiteralPath $indexPath -Value ("`r`n{0}: {1}`r`nEvidence: `"{2}`"" -f $Label, $Status, $matchText)
}

Add-Content -LiteralPath $indexPath -Value "`r`nSYSTEM HEALTH SUMMARY"
Add-EvidenceLine -Label "CPU" -Status "CHECK" -FileName "baseline_systeminfo.txt" -Pattern "Processor\(s\)|Processor:"
Add-EvidenceLine -Label "RAM" -Status "CHECK" -FileName "baseline_systeminfo.txt" -Pattern "Total Physical Memory"
Add-EvidenceLine -Label "Storage" -Status "CHECK" -FileName "storage_health.txt" -Pattern "HealthStatus|OperationalStatus|FriendlyName"
Add-EvidenceLine -Label "Display" -Status "CHECK" -FileName "baseline_dxdiag.txt" -Pattern "Card name:|Display Devices|Current Mode:"
Add-EvidenceLine -Label "Events" -Status "CHECK" -FileName "recent_errors.txt" -Pattern "TimeCreated:|PowerShell message:|No matching"

Add-Content -LiteralPath $indexPath -Value @"

PSU voltage: LAB ONLY - multimeter, not tested at home

SAFETY
- Read-only diagnostic queries were used.
- No repair, format, clean, or disk modification commands were run.
- Computer name, username, and hardware serial numbers must be redacted as XXXX before sharing.
- Review reports for other private information before publishing.

RELIABILITY MONITOR
Open with: perfmon /rel
Take a screenshot and save it as reliability_monitor.png in this folder.

NOTE
All health statuses remain CHECK until the collected evidence is reviewed.
END OF INDEX
"@

Write-Host ""
Write-Host "Diagnostic collection finished."
Write-Host "Reports folder: $OutputDir"
Write-Host "NEXT: Open perfmon /rel, take a screenshot, and save it as reliability_monitor.png in the reports folder."
Write-Host "NEXT: Review and redact personal details before sharing."
